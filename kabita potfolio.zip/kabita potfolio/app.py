from flask import Flask, request, jsonify
import sqlite3
import os
from datetime import datetime

app = Flask(__name__, static_folder='.', static_url_path='')

# Database setup
def init_db():
    # Create database directory if it doesn't exist
    os.makedirs('database', exist_ok=True)
    
    conn = sqlite3.connect('database/messages.db')
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        message TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    conn.commit()
    conn.close()

# Initialize database
init_db()

# Route to serve the static HTML file
@app.route('/')
def home():
    return app.send_static_file('index.html')

# API endpoint to handle form submissions
@app.route('/send_message', methods=['POST'])
def send_message():
    try:
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')
        
        # Validate inputs
        if not name or not email or not message:
            return jsonify({"error": "All fields are required"}), 400
        
        # Store in database
        conn = sqlite3.connect('database/messages.db')
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO messages (name, email, message, timestamp) VALUES (?, ?, ?, ?)",
            (name, email, message, datetime.now())
        )
        conn.commit()
        conn.close()
        
        return jsonify({"success": "Message sent successfully!"}), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# API to get all messages (for admin purposes)
@app.route('/admin/messages', methods=['GET'])
def get_messages():
    try:
        conn = sqlite3.connect('database/messages.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM messages ORDER BY timestamp DESC")
        messages = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({"messages": messages}), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)